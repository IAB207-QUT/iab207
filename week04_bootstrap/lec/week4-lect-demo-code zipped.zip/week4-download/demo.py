from reservation.hotel import Room

room = Room('standard','description', 100,120 )
print(room)