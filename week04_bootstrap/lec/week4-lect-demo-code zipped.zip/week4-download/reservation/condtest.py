cards=[]
cards.append('jack')
print(cards)
cards.append('queen')
print(cards)
cards.append('king')
print(cards)
print(len(cards))

p='hello'
q=p
p.replace('h','L')
print('val of q is ', q)
print('val of p is ', p)

